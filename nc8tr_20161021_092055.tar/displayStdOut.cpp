#include "displayStdOut.h"

void displayStdOut::showMessage(std::string const message) {
	std::cout << message << std::endl;
}
